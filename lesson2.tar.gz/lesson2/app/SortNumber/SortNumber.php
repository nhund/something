<?php 
namespace App\SortNumber;

/**
 * Class SortNumber
 * @package App
 */
interface SortNumber
{
	public function sort($numberes);
}