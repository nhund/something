<?php 
namespace App\DisplayStyle;

/**
* 
*class DisplayStyle
* @package App\DisplayStyle
*/
interface DisplayStyle 
{
	public function display($numberes);
}